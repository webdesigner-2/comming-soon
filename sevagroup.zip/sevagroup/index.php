<?php include('header.php'); ?>
<!-- ======= Hero Section ======= -->

<section id="hero" class="d-flex flex-column justify-content-center">
  <div class="container" data-aos="zoom-in" data-aos-delay="100">
    <div class="row">
      <div class="col-md-8">
        <h1 class="top-title-1">Seva Group</h1>
        <p> Seva Automotive was founded in 1985 and headquartered in Dwarka, Nashik. 
          We entered the Indian automotive industry at a revolutionary time that was spearheaded by Maruti, 
          especially after the launch of the iconic Maruti 800 in 1983. </p>
        <p> As it quickly became a customer favourite, we grew with it and were able to expand and open new facilities. In 1990, we shifted base to Ambad and opened one more facility in Nanded. </p>
        <p> In keeping with the times and ever-evolving automotive industry, the infrastructure at the sprawling 44,000 square feet Seva Nashik facility is state of the art, to facilitate excellence in the 3s - Sales, Service and Spares. Encouraged by the overwhelming response of our customers, we were able to quickly expand our reach to Nagpur in 1993, Dhule in 2004 and Nandurbar in 2009. We have now steadily grown to six showrooms across Maharashtra and countless workshops and R-Outlets. </p>
        <p> At Seva, the growth and happiness of our internal workforce is as important to us as customer service and satisfaction. By focusing our resources on creating a healthy work environment and inculcating the importance of excellent customer service in every employee, we have been able to create a loyal customer base. </p>
      </div>
    </div>
    
    <!-- <p>I'm <span class="typed" data-typed-items="Designer, Developer, Freelancer, Photographer"></span></p> -->
    
    <div class="social-links"> <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a> <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a> <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a> 
      <!-- <a href="#" class="google-plus"><i class="bx bxl-skype"></i></a>
        <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a> --> 
    </div>
  </div>
</section>
<!-- End Hero -->

<main id="main"> 
  
  <!-- ======= About Section ======= --> 
  <!-- <section id="about" class="about">
      <div class="container" data-aos="fade-up">
          <section class="customer-logos slider">
            <div class="slide"><img src="assets/images/image1.png"></div>
            <div class="slide"><img src="assets/images/image2.png"></div>
            <div class="slide"><img src="assets/images/image3.png"></div>
            <div class="slide"><img src="assets/images/image4.png"></div>
            <div class="slide"><img src="assets/images/image5.png"></div>
            <div class="slide"><img src="assets/images/image6.png"></div>
            <div class="slide"><img src="assets/images/image7.png"></div>
            <div class="slide"><img src="assets/images/image8.png"></div>
          </section>   
      </div>
    </section> --><!-- End About Section --> 
  
  <!-- ======= Facts Section ======= -->
    <section id="services" class="services">
    <div class="container">
      <div class="section-title">
        <h2>Our Group Companies</h2>
      </div>
    <div class="row">
        <div class="col-md-4 col-sm-6">
            <div class="product-grid7">
                <div class="product-image7">
                    <a href="company-group.php">
                        <img class="pic-1" src="assets/img/arena.png"/>
                        <img class="pic-2" src="assets/img/nexa-1.png">
                    </a>
                    <ul class="social">
                        <li><a href="" class="bx bxl-facebook"></a></li>
                        <li><a href="" class="bx bxl-instagram"></a></li>
                        <li><a href="" class="bx bxl-twitter"></a></li>
                    </ul>
                    <!-- <span class="product-new-label">New</span> -->
                </div>
                <div class="product-content">
                    <h3 class="title"><a href="company-group.php">Maruti Seva</a></h3>
                    <ul class="rating">
                        <li class="fa fa-star"></li>
                        <li class="fa fa-star"></li>
                        <li class="fa fa-star"></li>
                        <li class="fa fa-star"></li>
                        <li class="fa fa-star"></li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="col-md-4 col-sm-6">
            <div class="product-grid7">
                <div class="product-image7">
                    <a href="company-group.php">
                        <img class="pic-1" src="assets/img/rushabh.png">
                        <img class="pic-2" src="assets/img/rushabh-2.png">
                    </a>
                    <ul class="social">
                        <li><a href="" class="bx bxl-facebook"></a></li>
                        <li><a href="" class="bx bxl-instagram"></a></li>
                        <li><a href="" class="bx bxl-twitter"></a></li>
                    </ul>
                    <!-- <span class="product-new-label">New</span> -->
                </div>
                <div class="product-content">
                    <h3 class="title"><a href="company-group.php#rushabh">Rushabh</a></h3>
                    <ul class="rating">
                        <li class="fa fa-star"></li>
                        <li class="fa fa-star"></li>
                        <li class="fa fa-star"></li>
                        <li class="fa fa-star"></li>
                        <li class="fa fa-star"></li>
                    </ul>
                   
                </div>
            </div>
        </div>

         <div class="col-md-4 col-sm-6">
            <div class="product-grid7">
                <div class="product-image7">
                    <a href="company-group.php#nutridock">
                        <img class="pic-1" src="assets/img/nutridock-website.png">
                        <img class="pic-2" src="assets/img/nutridock-website-1.png">
                    </a>
                    <ul class="social">
                        <li><a href="" class="bx bxl-facebook"></a></li>
                        <li><a href="" class="bx bxl-instagram"></a></li>
                        <li><a href="" class="bx bxl-twitter"></a></li>
                    </ul>
                </div>
                <div class="product-content">
                    <h3 class="title"><a href="company-group.php#nutridock">Nutridock</a></h3>
                    <ul class="rating">
                        <li class="fa fa-star"></li>
                        <li class="fa fa-star"></li>
                        <li class="fa fa-star"></li>
                        <li class="fa fa-star"></li>
                        <li class="fa fa-star"></li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="col-md-4 col-sm-6">
            <div class="product-grid7">
                <div class="product-image7">
                    <a href="company-group.php#elementretail">
                        <img class="pic-1" src="assets/img/eliment-1.png">
                        <img class="pic-2" src="assets/img/eliment-2.png">
                    </a>
                    <ul class="social">
                        <li><a href="" class="bx bxl-facebook"></a></li>
                        <li><a href="" class="bx bxl-instagram"></a></li>
                        <li><a href="" class="bx bxl-twitter"></a></li>
                    </ul>
                   
                </div>
                <div class="product-content">
                    <h3 class="title"><a href="#">Element Retail</a></h3>
                    <ul class="rating">
                        <li class="fa fa-star"></li>
                        <li class="fa fa-star"></li>
                        <li class="fa fa-star"></li>
                        <li class="fa fa-star"></li>
                        <li class="fa fa-star"></li>
                    </ul> 
                </div>
            </div>
        </div>

        <div class="col-md-4 col-sm-6">
            <div class="product-grid7">
                <div class="product-image7">
                    <a href="company-group.php#gaint-india">
                        <img class="pic-1" src="assets/img/gaint-india.png">
                        <img class="pic-2" src="assets/img/gaint-india-2.png">
                    </a>
                    <ul class="social">
                        <li><a href="" class="bx bxl-facebook"></a></li>
                        <li><a href="" class="bx bxl-instagram"></a></li>
                        <li><a href="" class="bx bxl-twitter"></a></li>
                    </ul>
                    <!-- <span class="product-new-label">New</span> -->
                </div>
                <div class="product-content">
                    <h3 class="title"><a href="company-group.php#gaint-india">Giantindia</a></h3>
                    <ul class="rating">
                        <li class="fa fa-star"></li>
                        <li class="fa fa-star"></li>
                        <li class="fa fa-star"></li>
                        <li class="fa fa-star"></li>
                        <li class="fa fa-star"></li>
                    </ul>
                   
                </div>
            </div>
        </div>

        <div class="col-md-4 col-sm-6">
            <div class="product-grid7">
                <div class="product-image7">
                    <a href="company-group.php#elementistore">
                        <img class="pic-1" src="assets/img/elementistore.png">
                        <img class="pic-2" src="assets/img/elementistore-2.png">
                    </a>
                    <ul class="social">
                        <li><a href="" class="bx bxl-facebook"></a></li>
                        <li><a href="" class="bx bxl-instagram"></a></li>
                        <li><a href="" class="bx bxl-twitter"></a></li>
                    </ul>
                    <!-- <span class="product-new-label">New</span> -->
                </div>
                <div class="product-content">
                    <h3 class="title"><a href="company-group.php#elementistore">Elementistore</a></h3>
                    <ul class="rating">
                        <li class="fa fa-star"></li>
                        <li class="fa fa-star"></li>
                        <li class="fa fa-star"></li>
                        <li class="fa fa-star"></li>
                        <li class="fa fa-star"></li>
                    </ul>
                   
                </div>
            </div>
        </div>

        

    </div>
    </div>
  </section>
  <!-- End Facts Section -->
  
  <!-- <section id="portfolio" class="portfolio section-bg">
    <div class="container aos-init aos-animate" data-aos="fade-up">
      <div class="section-title">
        <h2>Seva Social Foundation Event</h2>
      </div>
      <div class="aos-init aos-animate" data-aos="fade-up" data-aos-delay="200">
        <div class="">
          <div id="blogCarousel" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators" style="margin-bottom: -15px;">
              <li data-target="#blogCarousel" data-slide-to="0" class="active" style="background-color:#444"></li>
              <li data-target="#blogCarousel" data-slide-to="1" style="background-color:#444"></li>
            </ol>
            <div class="carousel-inner">
              <div class="carousel-item active">
                <div class="row">
                  <div class="col-md-4">
                    <div class="portfolio-wrap"> 
                      <a href="#"> 
                      <img src="assets/img/group-img.png" alt="Image" style="max-width:100%;"/>
                      <div class="portfolio-info">
                        <div class="portfolio-links"> <a href="assets/img/group-img.png" data-gall="portfolioGallery" class="venobox vbox-item" title="Event For how to become Good Volunteer"> <i class="bx bx-plus"></i> </a> 
                          <a href="portfolio-details.php" data-gall="portfolioDetailsGallery" data-vbtype="iframe" class="venobox vbox-item" title="Portfolio Details"> <i class="bx bx-link"></i> </a> </div>
                      </div>
                      </a> 
                    </div>
                    <h4 class="event-title">Event For how to become Good Volunteer</h4>
                  </div>
                  <div class="col-md-4"> 
                    <div class="portfolio-wrap"> 
                      <a href="#"> 
                       <img src="assets/img/hospital.png" alt="Image" style="max-width:100%;">
                       <div class="portfolio-info">
                        <div class="portfolio-links"> <a href="assets/img/hospital.png" data-gall="portfolioGallery" class="venobox vbox-item" title="Event For how to become Good Volunteer"> <i class="bx bx-plus"></i> 
                        </a> 
                        <a href="portfolio-details.php" data-gall="portfolioDetailsGallery" data-vbtype="iframe" class="venobox vbox-item" title="Portfolio Details"> <i class="bx bx-link"></i> </a> </div>
                      </div> 
                      </a>
                     </div> 
                    <h4 class="event-title">Event For how to become Good Volunteer</h4>
                </div>
                  <div class="col-md-4"> 
                    <div class="portfolio-wrap">
                    <a href="#"> <img src="assets/img/child-titment.png" alt="Image" style="max-width:100%;"> 
                      <div class="portfolio-info">
                        <div class="portfolio-links"> 
                          <a href="assets/img/child-titment.png" data-gall="portfolioGallery" class="venobox vbox-item" title="Event For how to become Good Volunteer"> <i class="bx bx-plus"></i> 
                          </a> 
                          <a href="portfolio-details.php" data-gall="portfolioDetailsGallery" data-vbtype="iframe" class="venobox vbox-item" title="Portfolio Details"> <i class="bx bx-link"></i> 
                          </a> 
                        </div>
                      </div> 
                    </a>
                     </div>
                    <h4 class="event-title">Event For how to become Good Volunteer</h4>
                </div>
              </div>
            </div>
              
              <div class="carousel-item">
                <div class="row">
                  <div class="col-md-4"> 
                   <div class="portfolio-wrap">
                    <a href="#"> 
                      <img src="assets/img/child-titment.png" alt="Image" style="max-width:100%;"> 
                      <div class="portfolio-info">
                        <div class="portfolio-links"> 
                          <a href="assets/img/child-titment.png" data-gall="portfolioGallery" class="venobox vbox-item" title="Event For how to become Good Volunteer"> 
                            <i class="bx bx-plus"></i> 
                          </a> 
                          <a href="portfolio-details.php" data-gall="portfolioDetailsGallery" data-vbtype="iframe" class="venobox vbox-item" title="Portfolio Details"> 
                            <i class="bx bx-link"></i> 
                          </a> 
                        </div>
                      </div> 
                    </a>
                    </div>
                    <h4 class="event-title">Event For how to become Good Volunteer</h4>
                  </div>
                  <div class="col-md-4"> 
                    <div class="portfolio-wrap">
                    <a href="#"> 
                      <img src="assets/img/child-titment.png" alt="Image" style="max-width:100%;"> 
                      <div class="portfolio-info">
                        <div class="portfolio-links"> 
                          <a href="assets/img/child-titment.png" data-gall="portfolioGallery" class="venobox vbox-item" title="Event For how to become Good Volunteer"> 
                            <i class="bx bx-plus"></i> 
                          </a> 
                          <a href="portfolio-details.php" data-gall="portfolioDetailsGallery" data-vbtype="iframe" class="venobox vbox-item" title="Portfolio Details"> 
                            <i class="bx bx-link"></i> 
                          </a> 
                        </div>
                      </div> 
                    </a>
                     </div>
                    <h4 class="event-title">Event For how to become Good Volunteer</h4>
                  </div>
                  <div class="col-md-4"> 
                    <div class="portfolio-wrap">
                    <a href="#"> <img src="assets/img/child-titment.png" alt="Image" style="max-width:100%;"> 
                      <div class="portfolio-info">
                        <div class="portfolio-links"> 
                          <a href="assets/img/child-titment.png" data-gall="portfolioGallery" class="venobox vbox-item" title="Event For how to become Good Volunteer"> <i class="bx bx-plus"></i> 
                          </a> 
                          <a href="portfolio-details.php" data-gall="portfolioDetailsGallery" data-vbtype="iframe" class="venobox vbox-item" title="Portfolio Details"> <i class="bx bx-link"></i> 
                          </a> 
                        </div>
                      </div> 
                    </a>
                    </div>
                    <h4 class="event-title">Event For how to become Good Volunteer</h4>
                  </div>
                </div>
              </div>
             </div>
          </div>
        </div>
      </div>
    </div>
  </section> -->
</main>
<!-- End #main -->
<?php include('footer.php')?>
