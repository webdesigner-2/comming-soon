<?php include('header.php');?>
<style type="text/css">
  .carousel-inner{
    max-height: 500px;
  }
</style>
<div class="text-center bg-fixed breadcrumb-area dark padding-xl shadow text-light" style="background-image:url(assets/images/banner.png);background-position: top center;">
  <div class="container">
    <div class="row">
      <div class="col-sm-12 text-center">
        <h2 class="text-uppercase text-bold">Our Group Companies</h2>
      </div>
    </div>
  </div>
</div>
<section class="our-group-company">
  <div class="container">
    <div class="row custome-2">
       <div class="company-logo"> 
        <a href="#seva">
          <img src="assets/images/logo/seva.svg" class="img-fluid"/>
        </a>
       </div> 
       <div class="company-logo"> 
        <a href="#nexa">
          <img src="assets/images/logo/intro-nexa.svg" class="img-fluid"/>
        </a>
       </div> 
       <div class="company-logo"> 
        <a href="#rushabh">
          <img src="assets/images/logo/rushabh-logo.svg" class="img-fluid" />
        </a>
       </div> 
     
       <div class="company-logo"> 
        <a href="#nutridock">
          <img src="assets/images/logo/nutridock-logo.svg" class="img-fluid" />
        </a>
       </div> 
       <div class="company-logo"> 
        <a href="#gaint">
          <img src="assets/images/logo/gaint-logo.png" class="img-fluid" />
        </a>
       </div>
       <div class="company-logo"> 
        <a href="#elemnt">
          <img src="assets/images/logo/element-logo.png" class="img-fluid" />
        </a>
       </div> 
    </div>
  </div>
</section>

<section class="social-foundation">
  <div class="container">
     <div class="row" id="seva">
      <div class="col-md-6 col-lg-5 mb-3">
        <div id="rushabh" class="carousel slide" data-ride="carousel"> 
          <!-- The slideshow -->
          <div class="carousel-inner">
            <div class="carousel-item active"> <img src="assets/img/arena.png" class="img-fluid"> </div>
            <div class="carousel-item"> <img src="assets/img/arena-2.png" class="img-fluid"> </div>
            <div class="carousel-item"> <img src="assets/img/nexa-1.png" class="img-fluid"> </div>
            <div class="carousel-item"> <img src="assets/img/commercial.png" class="img-fluid"> </div>
          </div>
        </div>
      </div>
      <div class="col-md-6 col-lg-7 align-self-center">
        <div class="moto-widget moto-spacing-top-medium">
          <div class="moto-spacing-left-medium pl-0"> 
            <a href="marutiseva.com/" class="moto-widget-button-link moto-size-small moto-link" style="background-color: #2a3096;"> 
             <span class="moto-widget-button-label">Maruti Seva</span> 
            </a> 
          </div>
          <div class="moto-widget-text-content">
            <h2 class="moto-text_system_6">Arena - Nexa - Comercial </h2>
          </div>
          <div class="moto-spacing-top-small"> rushabh Honda is one of the oldest Honda Dealers in Nashik. Rushabh Honda has its headquarters located in Mumbai Naka. We have our service branch at Ambad and sales branch at Uttam Nagar.
            We provide both sales and servicing at Mhasrul and Indira Nagar. We are equipped with finest Honda Trained staff in Sales, Spare and Services areas. We are known for our friendly atmosphere and team work spirit delivering quality service for years. We strive towards excellence and were awarded for Best Runner up Dealer from the West Region. We try to get maximum out of every part of our firm and are awarded as best 1st Runner up Award for Annual Maintenance Contract, in the West Region, by Honda. </div>
          <a href="marutiseva.com/" target="_blank" class="btn btn-outline-dark btn-lg mt-3 text-uppercase" style="font-size: 15px;border-radius: 0px">Read more</a> </div>
      </div>
    </div>

    <hr class="moto-widget-divider-line" />
    <div class="row" id="nexa">
      <div class="col-md-6 col-lg-7 align-self-center">
        <div class="moto-widget moto-spacing-top-medium">
          <div class="moto-spacing-left-medium pl-0"> 
            <a href="https://rushabh2w.com/" class="moto-widget-button-link moto-size-small moto-link" style="background-color: #f00;"> 
             <span class="moto-widget-button-label">Rushabh</span> 
            </a> 
          </div>
          <div class="moto-widget-text-content">
            <h2 class="moto-text_system_6"> Honda Two Wheeler </h2>
          </div>
          <div class="moto-spacing-top-small"> rushabh Honda is one of the oldest Honda Dealers in Nashik. Rushabh Honda has its headquarters located in Mumbai Naka. We have our service branch at Ambad and sales branch at Uttam Nagar.
            We provide both sales and servicing at Mhasrul and Indira Nagar. We are equipped with finest Honda Trained staff in Sales, Spare and Services areas. We are known for our friendly atmosphere and team work spirit delivering quality service for years. We strive towards excellence and were awarded for Best Runner up Dealer from the West Region. We try to get maximum out of every part of our firm and are awarded as best 1st Runner up Award for Annual Maintenance Contract, in the West Region, by Honda. </div>
          <a href="https://rushabh2w.com/" target="_blank" class="btn btn-outline-dark btn-lg mt-3 text-uppercase" style="font-size: 15px;border-radius: 0px">Read more</a> </div>
      </div>
      <div class="col-md-6 col-lg-5 mb-3">
        <div id="rushabh" class="carousel slide" data-ride="carousel"> 
          <!-- The slideshow -->
          <div class="carousel-inner">
            <div class="carousel-item active"> <img src="assets/img/rushabh.png" class="img-fluid"> </div>
            <div class="carousel-item"> <img src="assets/img/rushabh-2.png" class="img-fluid"> </div>
          </div>
        </div>
      </div>
    </div>

    <hr class="moto-widget-divider-line" />

    
    <div class="row" id="nutridock">
      <div class="col-md-6 col-lg-5 mb-3">
        <div id="rushabh" class="carousel slide" data-ride="carousel"> 
          <!-- The slideshow -->
          <div class="carousel-inner">
            <div class="carousel-item active"> <img src="assets/img/nutridock-website.png" class="img-fluid"> </div>
            <div class="carousel-item"> <img src="assets/img/nutridock-website-1.png" class="img-fluid"> </div>
          </div>
        </div>
      </div>
      <div class="col-md-6 col-lg-7 align-self-center">
        <div class="moto-widget moto-spacing-top-medium">
          <div class="moto-spacing-left-medium pl-0"> 
            <a href="https:nutridock.com/" class="moto-widget-button-link moto-size-small moto-link" style="background-color: #90D124;"> 
             <span class="moto-widget-button-label">Nutridock</span> 
            </a> 
          </div>
          <div class="moto-widget-text-content">
            <h2 class="moto-text_system_6">Nutrition Food - Nutridock</h2>
          </div>
          <div class="moto-spacing-top-small"> It’s not about dieting. It’s about eating right. Get personalised meal plans, recipes & immunity tips tailor-made for your lifestyle, on the Nutridock app 
          <p> To impart knowledge about the importance of good nutrition in the journey to physical, mental and emotional well-being. </p>
          <p>To be the go-to source of information about food and nutrition, and educate people so that healthy living comes naturally. </p>
          <p>Log your daily meals, get personalised nutrition advice and grow fitter while eating all the foods you love!</p>
           </div>
          <a href="https:nutridock.com/" target="_blank" class="btn btn-outline-dark btn-lg mt-3 text-uppercase" style="font-size: 15px;border-radius: 0px">Read more</a> </div>
      </div>
    </div>
    <hr class="moto-widget-divider-line" />
    <div class="row" id="gaint">
      <div class="col-md-6 col-lg-7">
        <div class="moto-widget moto-spacing-top-medium">
          <div class="moto-spacing-left-medium pl-0"> 
            <a href="https://giantindia.com/" class="moto-widget-button-link moto-size-small moto-link" style="background-color: #01018c;"> 
             <span class="moto-widget-button-label">Gaint India</span> 
            </a> 
          </div>
          <div class="moto-widget-text-content">
            <h2 class="moto-text_system_6">DANDELION</h2>
          </div>
          <div class="moto-spacing-top-small"> rushabh Honda is one of the oldest Honda Dealers in Nashik. Rushabh Honda has its headquarters located in Mumbai Naka. We have our service branch at Ambad and sales branch at Uttam Nagar.
            We provide both sales and servicing at Mhasrul and Indira Nagar. We are equipped with finest Honda Trained staff in Sales, Spare and Services areas. We are known for our friendly atmosphere and team work spirit delivering quality service for years. We strive towards excellence and were awarded for Best Runner up Dealer from the West Region. We try to get maximum out of every part of our firm and are awarded as best 1st Runner up Award for Annual Maintenance Contract, in the West Region, by Honda. </div>
          <a href="https://giantindia.com/" target="_blank" class="btn btn-outline-dark btn-lg mt-3 text-uppercase" style="font-size: 15px;border-radius: 0px">Read more</a> </div>
      </div>
      <div class="col-md-6 col-lg-5 mb-3">
        <div id="rushabh" class="carousel slide" data-ride="carousel"> 
          <!-- The slideshow -->
          <div class="carousel-inner">
            <div class="carousel-item active"> <img src="assets/img/gaint-website.png" class="img-fluid"> </div>
            <div class="carousel-item"> <img src="assets/img/gaint-website-1.png" class="img-fluid"> </div>
          </div>
        </div>
      </div>
    </div>
    <hr class="moto-widget-divider-line" />
    <div class="row" id="elemnt">
      <div class="col-md-6 col-lg-5 mb-3">
        <div id="rushabh" class="carousel slide" data-ride="carousel"> 
          <!-- The slideshow -->
          <div class="carousel-inner">
            <div class="carousel-item active"> <img src="assets/img/element-website.png" class="img-fluid"> </div>
            <div class="carousel-item"> <img src="assets/img/element-website-2.png" class="img-fluid"> </div>
          </div>
        </div>
      </div>
      <div class="col-md-6 col-lg-7">
        <div class="moto-widget moto-spacing-top-medium">
          <div class="moto-spacing-left-medium pl-0"> 
            <a href="elementretail.in/" class="moto-widget-button-link moto-size-small moto-link" style="background-color: #a3d361;"> 
             <span class="moto-widget-button-label">Element Retail</span> 
            </a> 
          </div>
          <div class="moto-widget-text-content">
            <h2 class="moto-text_system_6">Element Retail</h2>
          </div>
          <div class="moto-spacing-top-small"> rushabh Honda is one of the oldest Honda Dealers in Nashik. Rushabh Honda has its headquarters located in Mumbai Naka. We have our service branch at Ambad and sales branch at Uttam Nagar.
            We provide both sales and servicing at Mhasrul and Indira Nagar. We are equipped with finest Honda Trained staff in Sales, Spare and Services areas. We are known for our friendly atmosphere and team work spirit delivering quality service for years. We strive towards excellence and were awarded for Best Runner up Dealer from the West Region. We try to get maximum out of every part of our firm and are awarded as best 1st Runner up Award for Annual Maintenance Contract, in the West Region, by Honda. </div>
          <a href="elementretail.in/" target="_blank" class="btn btn-outline-dark btn-lg mt-3 text-uppercase" style="font-size: 15px;border-radius: 0px">Read more</a> </div>
      </div>
    </div>
  </div>
</section>

<div class="moto-widget moto-widget-block d-none d-sm-block" style="background-image:url(assets/images/mt-projects.jpg);background-size:cover;">
<div class="container-fluid">
  <div class="row">
    <div class="moto-cell col-sm-12">
      <div class="moto-widget moto-widget-row row-gutter-0">
        <div class="container-fluid">
          <div class="row">
            <div class="moto-widget col-sm-7 moto-spacing-top-large" style="background-color:rgba(0, 0, 0, 0.7);" >
              <div class="moto-widget moto-widget-text">
                <div class="moto-widget-text-content moto-widget-text-editable">
                  <h2 class="moto-text_system_5"><strong>THERE ARE LOTS OF WAYS TO MAKE GOOD THINGS HAPPEN</strong></h2>
                </div>
              </div>
              <div class="moto-widget moto-widget-row ">
                <div class="container-fluid">
                  <div class="row">
                    <div class="moto-widget col-sm-6">
                      <div class="moto-widget moto-widget-text">
                        <div class="moto-widget-text-content">
                          <ul>
                            <li class="moto-text_270">Help people in need</li>
                            <li class="moto-text_270">Take action in an emergency</li>
                            <li class="moto-text_270">Take part in a charity event</li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div class="moto-widget col-sm-6">
                      <div class="moto-widget moto-widget-text">
                        <div class="moto-widget-text-content">
                          <ul>
                            <li class="moto-text_270">Celebrate an occasion</li>
                            <li class="moto-text_270">Start new business</li>
                            <li class="moto-text_270">Realize education project</li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php include('footer.php')?>
